
  # APIGuard

  This is a code bundle for APIGuard. The original project is available at https://www.figma.com/design/SCjc9ZG8KiNEJJoF6wxGh7/APIGuard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  