import { useState } from "react";
import { Menu } from "lucide-react";
import { AppSidebar } from "./components/AppSidebar";
import { LoginPage } from "./components/LoginPage";
import { RegisterPage } from "./components/RegisterPage";
import { DashboardPage } from "./components/DashboardPage";
import { ProjectsPage } from "./components/ProjectsPage";
import { ProjectDetailPage } from "./components/ProjectDetailPage";
import { EndpointDetailPage } from "./components/EndpointDetailPage";
import { EndpointFormPage } from "./components/EndpointFormPage";
import { AlertsPage } from "./components/AlertsPage";

type Page =
  | "login"
  | "register"
  | "dashboard"
  | "projects"
  | "project-detail"
  | "endpoint-detail"
  | "endpoint-form"
  | "alerts"
  | "settings";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentPage, setCurrentPage] = useState<Page>("login");
  const [selectedProjectId, setSelectedProjectId] = useState<
    number | null
  >(null);
  const [selectedEndpointId, setSelectedEndpointId] = useState<
    number | null
  >(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] =
    useState(false);

  const handleLogin = () => {
    setIsAuthenticated(true);
    setCurrentPage("dashboard");
  };

  const handleRegister = () => {
    setIsAuthenticated(true);
    setCurrentPage("dashboard");
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentPage("login");
  };

  const handleNavigate = (page: string, id?: number) => {
    if (page === "project-detail" && id) {
      setSelectedProjectId(id);
      setCurrentPage("project-detail");
    } else if (page === "endpoint-detail" && id) {
      setSelectedEndpointId(id);
      setCurrentPage("endpoint-detail");
    } else if (page === "endpoint-form") {
      setIsEditMode(!!id);
      setCurrentPage("endpoint-form");
    } else {
      setCurrentPage(page as Page);
    }
  };

  const handleBackToProjects = () => {
    setCurrentPage("projects");
    setSelectedProjectId(null);
  };

  const handleBackToProjectDetail = () => {
    setCurrentPage("project-detail");
    setSelectedEndpointId(null);
  };

  // Not authenticated - show login/register
  if (!isAuthenticated) {
    if (currentPage === "register") {
      return (
        <RegisterPage
          onRegister={handleRegister}
          onSwitchToLogin={() => setCurrentPage("login")}
          isDarkMode={isDarkMode}
        />
      );
    }
    return (
      <LoginPage
        onLogin={handleLogin}
        onSwitchToRegister={() => setCurrentPage("register")}
        isDarkMode={isDarkMode}
      />
    );
  }

  // Authenticated - show main app
  return (
    <div
      className={`flex min-h-screen ${isDarkMode ? "bg-gray-950" : "bg-gray-100"}`}
    >
      {/* Mobile Menu Button */}
      <button
        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        className={`md:hidden fixed top-4 left-4 z-50 p-2 rounded-lg ${
          isDarkMode
            ? "bg-gray-800 text-white"
            : "bg-white text-gray-900 shadow-md"
        }`}
      >
        <Menu className="h-6 w-6" />
      </button>

      {/* Mobile Overlay */}
      {isMobileMenuOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div
        className={`${
          isMobileMenuOpen
            ? "translate-x-0"
            : "-translate-x-full"
        } md:translate-x-0 fixed inset-y-0 left-0 z-40 transition-transform duration-300 ease-in-out`}
      >
        <AppSidebar
          currentPage={currentPage}
          onNavigate={(page) => {
            handleNavigate(page);
            setIsMobileMenuOpen(false);
          }}
          onLogout={() => {
            handleLogout();
            setIsMobileMenuOpen(false);
          }}
          isDarkMode={isDarkMode}
        />
      </div>

      <main className="flex-1 p-4 md:p-8 md:ml-64 overflow-auto">
        {/* Add top padding on mobile to account for menu button */}
        <div className="pt-12 md:pt-0">
          {currentPage === "dashboard" && (
            <DashboardPage
              isDarkMode={isDarkMode}
              onToggleDarkMode={() =>
                setIsDarkMode(!isDarkMode)
              }
            />
          )}
          {currentPage === "projects" && (
            <ProjectsPage
              onNavigate={handleNavigate}
              isDarkMode={isDarkMode}
            />
          )}
          {currentPage === "project-detail" && (
            <ProjectDetailPage
              onNavigate={handleNavigate}
              onBack={handleBackToProjects}
              isDarkMode={isDarkMode}
            />
          )}
          {currentPage === "endpoint-detail" && (
            <EndpointDetailPage
              onBack={handleBackToProjectDetail}
              onNavigate={handleNavigate}
              isDarkMode={isDarkMode}
            />
          )}
          {currentPage === "endpoint-form" && (
            <EndpointFormPage
              onBack={handleBackToProjectDetail}
              isEdit={isEditMode}
              isDarkMode={isDarkMode}
            />
          )}
          {currentPage === "alerts" && (
            <AlertsPage isDarkMode={isDarkMode} />
          )}
          {currentPage === "settings" && (
            <div
              className={
                isDarkMode ? "text-white" : "text-gray-900"
              }
            >
              <h1 className="text-3xl mb-2">Settings</h1>
              <p
                className={
                  isDarkMode ? "text-gray-400" : "text-gray-600"
                }
              >
                Configure your account and preferences
              </p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}